package com.example.mybooking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MybookingApplicationTests {

	@Test
	void contextLoads() {
	}

}
