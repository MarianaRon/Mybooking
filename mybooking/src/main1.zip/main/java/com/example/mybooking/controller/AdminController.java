package com.example.mybooking.controller;

public class AdminController {
}
