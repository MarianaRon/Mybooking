package com.example.mybooking.service;

public class BookingService {
}
