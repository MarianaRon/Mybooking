package com.example.mybooking.repository;

public interface BookingRepository {
}
