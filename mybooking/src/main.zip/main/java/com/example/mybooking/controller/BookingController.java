package com.example.mybooking.controller;

public class BookingController {
}
