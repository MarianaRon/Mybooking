package com.example.mybooking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MybookingApplication {

	public static void main(String[] args) {
		SpringApplication.run(MybookingApplication.class, args);
	}

}
