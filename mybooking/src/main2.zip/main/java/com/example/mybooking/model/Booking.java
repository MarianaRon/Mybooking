package com.example.mybooking.model;

public class Booking {
}
